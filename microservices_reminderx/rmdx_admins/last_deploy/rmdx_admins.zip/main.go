package main

import (
	"fmt"
	"os"

	"github.com/gin-gonic/gin"
)

func init() {

}

func main() {
	r := gin.Default()

	r.POST("/", AdminsPost)
	r.GET("/:id", AdminsGet)
	r.DELETE("/:id", AdminsDelete)
	r.PUT("/:id", AdminsPut)
	r.PATCH("/:id", AdminsPatch)

	err := r.Run(":" + os.Getenv("PORT"))

	if err != nil {
		panic("[Error] failed to start Gin server due to: " + err.Error())
	}
}

func AdminsPost(c *gin.Context) {
	// Return it
	c.JSON(200, gin.H{
		"admin": "OK",
	})
}

func AdminsGet(c *gin.Context) {

	//Get the id off url
	id := c.Param("id")
	fmt.Println(id)

	// Return it
	c.JSON(200, gin.H{
		"admin": "OK " + id,
	})
}

func AdminsDelete(c *gin.Context) {

	//Get the id off url
	id := c.Param("id")
	fmt.Println(id)

	// Return it
	c.JSON(200, gin.H{
		"admin": "OK " + id,
	})
}

func AdminsPut(c *gin.Context) {

	//Get the id off url
	id := c.Param("id")
	fmt.Println(id)

	// Return it
	c.JSON(200, gin.H{
		"admin": "OK " + id,
	})
}

func AdminsPatch(c *gin.Context) {

	//Get the id off url
	id := c.Param("id")
	fmt.Println(id)

	// Return it
	c.JSON(200, gin.H{
		"admin": "OK " + id,
	})
}
