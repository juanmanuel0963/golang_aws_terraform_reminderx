package handler

import (
	"github.com/gin-gonic/gin"
)

func AdminsPost(c *gin.Context) {
	// Return it
	c.JSON(200, gin.H{
		"admin": "OK",
	})
}

func AdminsGet(c *gin.Context) {
	// Return it
	c.JSON(200, gin.H{
		"admin": "OK",
	})
}

func AdminsDelete(c *gin.Context) {
	// Return it
	c.JSON(200, gin.H{
		"admin": "OK",
	})
}

func AdminsPut(c *gin.Context) {
	// Return it
	c.JSON(200, gin.H{
		"admin": "OK",
	})
}

func AdminsPatch(c *gin.Context) {
	// Return it
	c.JSON(200, gin.H{
		"admin": "OK",
	})
}
